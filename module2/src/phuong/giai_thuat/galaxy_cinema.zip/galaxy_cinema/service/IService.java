package phuong.giai_thuat.galaxy_cinema.service;

public interface IService {
}
