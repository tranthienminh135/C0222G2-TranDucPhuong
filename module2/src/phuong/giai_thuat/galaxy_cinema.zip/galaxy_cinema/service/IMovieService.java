package phuong.giai_thuat.galaxy_cinema.service;

public interface IMovieService {
    void display();
    void addNewMovie();
    void addNewShowTime();
    void deleteShowTime();
    void deleteMovie();
}
