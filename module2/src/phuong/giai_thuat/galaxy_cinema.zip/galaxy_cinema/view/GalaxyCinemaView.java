package phuong.giai_thuat.galaxy_cinema.view;

import phuong.giai_thuat.galaxy_cinema.controllers.GalaxyCinemaController;

public class GalaxyCinemaView {

    public static void main(String[] args) {
        GalaxyCinemaController.displayGalaxyCinemaManagement();
    }
}
